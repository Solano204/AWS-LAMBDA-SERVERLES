import json

def lambda_handler(event, context):
    # Parse Input
    body = json.loads(event.get('body', '{}'))
    country = body.get('country', 'USA')

    # Logic
    shipping_cost = 5.00 if country == 'USA' else 15.00

    # Response
    return {
        'statusCode': 200,
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
        },
        'body': json.dumps({'shipping_cost': shipping_cost})
    }
